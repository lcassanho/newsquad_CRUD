package br.com.fiap.newsquad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsquadApplicationTests {

	@Test
	void contextLoads() {
	}

}
